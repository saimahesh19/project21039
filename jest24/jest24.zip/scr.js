function func(){
		document.getElementById("image").src="g9.jfif";
}